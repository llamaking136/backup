#!/bin/bash

# Creates backup.py executable
chmod +x backup.py

# Copies backup.py to the user's choice
cp backup.py $1
